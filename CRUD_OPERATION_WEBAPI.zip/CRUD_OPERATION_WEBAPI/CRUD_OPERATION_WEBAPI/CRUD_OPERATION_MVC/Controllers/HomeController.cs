﻿using CRUD_OPERATION_MVC.Helper;
using CRUD_OPERATION_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CRUD_OPERATION_MVC.Controllers
{
    public class HomeController : Controller
    {
     

        ShopAPI _api = new ShopAPI();

        public async Task<IActionResult> Index()
        {
            List<ShopData> data = new List<ShopData>();
            HttpClient client = _api.FClient();
            HttpResponseMessage response = await client.GetAsync("api/ShopApi");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
               data = JsonConvert.DeserializeObject<List<ShopData>>(results);
            }
            return View(data);
        }

        public async Task<IActionResult>Details(int Id)
        {
            var data = new ShopData();
            HttpClient client = _api.FClient();
            HttpResponseMessage response = await client.GetAsync($"api/ShopApi/{Id}");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
               data = JsonConvert.DeserializeObject<ShopData>(results);

            }
            return View(data);
        }

        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(ShopData data)
        {
            HttpClient client = _api.FClient();

           

            var postTask =  client.PostAsJsonAsync<ShopData>("api/ShopApi",data);
            postTask.Wait();

            var result = postTask.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }


        public async Task<IActionResult> Delete(int Id)
        {
            
            HttpClient client = _api.FClient();
            HttpResponseMessage response = await client.DeleteAsync($"api/ShopApi/{Id}");
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int Id)
        {
           ShopData User = null; ;
            HttpClient client = _api.FClient();
            var responseTask = client.GetAsync($"api/ShopApi/{Id}");
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                var readTask = result.Content.ReadAsAsync<ShopData>();
                readTask.Wait();
                User = readTask.Result;
            }
            return View(User);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ShopData User)
        {
            HttpClient client = _api.FClient();
            var postTask = client.PutAsJsonAsync<ShopData>($"api/ShopApi/{User.ID}", User);
            postTask.Wait();

            var result = postTask.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }
       
            [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
