﻿using CRUD_OPERATION_WEBAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CRUD_OPERATION_WEBAPI.DataContext
{
    public class ShpoDbContext:DbContext
    {
        public ShpoDbContext(DbContextOptions<ShpoDbContext> options) : base(options)
        {
            
        }
        public DbSet<Shop> Shops { get; set; }
    }
}
